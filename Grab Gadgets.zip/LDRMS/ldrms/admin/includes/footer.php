<div class="copyright-w3layouts py-xl-3 py-2 mt-xl-5 mt-4 text-center">
                <p>© Grab Gadgets
                    
                </p>
            </div>