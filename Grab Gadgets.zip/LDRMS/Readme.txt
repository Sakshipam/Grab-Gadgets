How to run the Laptop And Desktop Rental Management System(LDRMS) Project

1. Download the  zip file

2. Extract the file and copy ldrms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name ldrmsdb

6. Import ldrmsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/ldrms (frontend)



Credential for admin panel :
Username: admin
Password: Test@123


Credential for  User panel :
Username: jdoe@gmail.com/1212343455
Password: Test@123
Or Register a new User.